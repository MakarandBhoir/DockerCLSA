Create/Build Image
    sudo docker build -t feedbackapp:v1.0 .

Create and run container without volume (problem)
    sudo docker run -p 8080:80 --name feedbackapp-container --rm  feedbackapp:v1.0 (by default runs in attached mode. to exit require to stop container)

Run the application. You will not get the required output. To solve the problem create volumn

To see all running container
    sudo docker ps

Stop container
    sudo docker stop container_id or container_name (feedbackapp-container)

Create container with volume to store data (solution)
    sudo docker run -p 8080:80 --rm --name feedbackapp-container -v feedback:/app/feedback img_id
